@extends('layout.layout')
@php
    $title = 'Tambah Anggota';
    $subTitle = 'Tambah Anggota';
@endphp

@section('content')
    @if (session('success'))
        <x-alert type="success">{{ session('success') }}</x-alert>
    @endif
    @if (session('error'))
        <x-alert type="danger">{{ session('error') }}</x-alert>
    @endif

    <div class="grid grid-cols-12 gap-5">
        <div class="col-span-12">
            <div class="card border-0">
                <div class="card-header">
                    <h6 class="text-lg font-semibold mb-0">Form Tambah Anggota & Akun Login</h6>
                </div>
                <div class="card-body">
                    <form action="{{ route('anggota.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('POST')

                        <div class="grid grid-cols-12 gap-4">

                            {{-- ========== DATA USER / AKUN LOGIN ========== --}}
                            <div class="col-span-12">
                                <h5 class="text-md font-semibold mb-3 text-primary-600">📋 Data Akun Login</h5>
                            </div>

                            {{-- Nama Lengkap --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">Nama Lengkap <span class="text-danger-600">*</span></label>
                                <input type="text" name="name"
                                    class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}"
                                    required>
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Email --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">Email <span class="text-danger-600">*</span></label>
                                <input type="email" name="email"
                                    class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}"
                                    required>
                                @error('email')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">Email ini akan digunakan untuk login</small>
                            </div>

                            {{-- Password --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">Password <span class="text-danger-600">*</span></label>
                                <input type="password" name="password"
                                    class="form-control @error('password') is-invalid @enderror" required>
                                @error('password')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">Minimal 8 karakter</small>
                            </div>

                            {{-- Konfirmasi Password --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">Konfirmasi Password <span class="text-danger-600">*</span></label>
                                <input type="password" name="password_confirmation" class="form-control" required>
                            </div>

                            {{-- ========== DATA ANGGOTA ========== --}}
                            <div class="col-span-12 mt-4">
                                <hr>
                                <h5 class="text-md font-semibold my-3 text-primary-600">👤 Data Anggota</h5>
                            </div>

                            {{-- ID Kartu --}}
                            <div class="col-span-12">
                                <label class="form-label">Fingerprint <span class="text-danger-600">*</span></label>
                                <input type="text" name="id_kartu"
                                    class="form-control @error('id_kartu') is-invalid @enderror"
                                    value="{{ old('id_kartu') }}" required>
                                @error('id_kartu')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- No Telepon --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">No Telepon <span class="text-danger-600">*</span></label>
                                <input type="text" name="no_telp"
                                    class="form-control @error('no_telp') is-invalid @enderror"
                                    value="{{ old('no_telp') }}" required>
                                @error('no_telp')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Jenis Kelamin --}}
                            <div class="col-span-12 md:col-span-6">
                                <label class="form-label">Jenis Kelamin <span class="text-danger-600">*</span></label>
                                <select name="jenis_kelamin"
                                    class="form-control @error('jenis_kelamin') is-invalid @enderror" required>
                                    <option value="">-- Pilih Jenis Kelamin --</option>
                                    <option value="Laki-laki" {{ old('jenis_kelamin') == 'Laki-laki' ? 'selected' : '' }}>
                                        Laki-laki</option>
                                    <option value="Perempuan" {{ old('jenis_kelamin') == 'Perempuan' ? 'selected' : '' }}>
                                        Perempuan</option>
                                </select>
                                @error('jenis_kelamin')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Tempat Lahir --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Tempat Lahir <span class="text-danger-600">*</span></label>
                                <input type="text" name="tempat_lahir"
                                    class="form-control @error('tempat_lahir') is-invalid @enderror"
                                    value="{{ old('tempat_lahir') }}" required>
                                @error('tempat_lahir')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Tanggal Lahir --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Tanggal Lahir <span class="text-danger-600">*</span></label>
                                <input type="date" name="tgl_lahir"
                                    class="form-control @error('tgl_lahir') is-invalid @enderror"
                                    value="{{ old('tgl_lahir') }}" required>
                                @error('tgl_lahir')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Tanggal Daftar --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Tanggal Daftar <span class="text-danger-600">*</span></label>
                                <input type="date" name="tgl_daftar"
                                    class="form-control @error('tgl_daftar') is-invalid @enderror"
                                    value="{{ old('tgl_daftar', date('Y-m-d')) }}" required>
                                @error('tgl_daftar')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Golongan Darah --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Golongan Darah <span class="text-danger-600">*</span></label>
                                <select name="gol_darah" class="form-control @error('gol_darah') is-invalid @enderror"
                                    required>
                                    <option value="">-- Pilih Golongan Darah --</option>
                                    <option value="A" {{ old('gol_darah') == 'A' ? 'selected' : '' }}>A</option>
                                    <option value="B" {{ old('gol_darah') == 'B' ? 'selected' : '' }}>B</option>
                                    <option value="AB" {{ old('gol_darah') == 'AB' ? 'selected' : '' }}>AB</option>
                                    <option value="O" {{ old('gol_darah') == 'O' ? 'selected' : '' }}>O</option>
                                </select>
                                @error('gol_darah')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Tinggi --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Tinggi (cm) <span class="text-danger-600">*</span></label>
                                <input type="number" name="tinggi"
                                    class="form-control @error('tinggi') is-invalid @enderror"
                                    value="{{ old('tinggi') }}" required>
                                @error('tinggi')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Berat --}}
                            <div class="col-span-12 md:col-span-4">
                                <label class="form-label">Berat (kg) <span class="text-danger-600">*</span></label>
                                <input type="number" name="berat"
                                    class="form-control @error('berat') is-invalid @enderror"
                                    value="{{ old('berat') }}" required>
                                @error('berat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Alamat --}}
                            <div class="col-span-12">
                                <label class="form-label">Alamat <span class="text-danger-600">*</span></label>
                                <textarea name="alamat" class="form-control @error('alamat') is-invalid @enderror" rows="3" required>{{ old('alamat') }}</textarea>
                                @error('alamat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Riwayat Kesehatan --}}
                            <div class="col-span-12">
                                <label class="form-label">Riwayat Kesehatan</label>
                                <textarea name="riwayat_kesehatan" class="form-control @error('riwayat_kesehatan') is-invalid @enderror"
                                    rows="3">{{ old('riwayat_kesehatan') }}</textarea>
                                @error('riwayat_kesehatan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            {{-- Status Finger --}}
                            <div class="col-span-12">
                                <label class="form-label">Status Fingerprint <span
                                        class="text-danger-600">*</span></label>
                                <select name="status_finger"
                                    class="form-control @error('status_finger') is-invalid @enderror" required>
                                    <option value="2" {{ old('status_finger', '2') == '2' ? 'selected' : '' }}>—
                                        Default (Tidak Ada Aksi) —</option>
                                    <option value="0" {{ old('status_finger') == '0' ? 'selected' : '' }}>🟢 Enroll
                                        Fingerprint</option>
                                    <option value="1" {{ old('status_finger') == '1' ? 'selected' : '' }}>🔴 Delete
                                        Fingerprint</option>
                                </select>
                                @error('status_finger')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">Enroll = daftarkan sidik jari, Delete = hapus sidik jari, Default
                                    = tidak ada aksi</small>
                            </div>

                            {{-- Foto --}}
                            <div class="col-span-12">
                                <label class="form-label">Foto <span class="text-danger-600">*</span></label>
                                <input id="photo-input"
                                    class="border border-neutral-200 w-full rounded-lg @error('photo') is-invalid @enderror"
                                    type="file" name="photo" accept="image/*" required>
                                @error('photo')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div id="photo-preview-wrap" class="hidden mt-2 flex items-center gap-3">
                                    <img id="photo-preview" src="" alt="Preview" class="w-16 h-16 rounded-lg object-cover border border-neutral-200">
                                    <span id="photo-size-info" class="text-xs text-neutral-500"></span>
                                </div>
                            </div>

                            {{-- Tombol --}}
                            <div class="col-span-12 mt-4">
                                <div class="form-group flex items-center justify-end gap-2">
                                    <button type="submit" class="btn btn-primary-600">Simpan Anggota & Akun</button>
                                    <a href="{{ route('anggota.index') }}"
                                        class="text-danger-600 focus:bg-danger-600 hover:bg-danger-700 border border-danger-600 hover:text-white focus:text-white focus:ring-4 focus:outline-none focus:ring-danger-300 font-medium rounded-lg text-base px-6 py-3">Batal</a>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>
(function () {
    const input    = document.getElementById('photo-input');
    const preview  = document.getElementById('photo-preview');
    const wrap     = document.getElementById('photo-preview-wrap');
    const sizeInfo = document.getElementById('photo-size-info');

    function fmtKB(bytes) { return (bytes / 1024).toFixed(0) + ' KB'; }

    input.addEventListener('change', function () {
        const file = this.files[0];
        if (!file) { wrap.classList.add('hidden'); return; }

        const origSize = file.size;
        const ext      = file.name.split('.').pop().toLowerCase();
        const noCanvas = ['heic', 'heif'].includes(ext);

        if (noCanvas || origSize < 300 * 1024) {
            // Tampilkan preview saja, skip kompresi
            const url = URL.createObjectURL(file);
            preview.src = url;
            wrap.classList.remove('hidden');
            sizeInfo.textContent = noCanvas
                ? fmtKB(origSize) + ' (format HEIC, tidak dikompresi)'
                : fmtKB(origSize) + ' (sudah kecil, tidak dikompresi)';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (ev) {
            const img = new Image();
            img.onload = function () {
                const MAX_W  = 800;
                const scale  = Math.min(1, MAX_W / img.width);
                const canvas = document.createElement('canvas');
                canvas.width  = Math.round(img.width  * scale);
                canvas.height = Math.round(img.height * scale);

                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                canvas.toBlob(function (blob) {
                    if (!blob || blob.size >= origSize) {
                        // Kompresi malah besar, pakai aslinya
                        preview.src = URL.createObjectURL(file);
                        wrap.classList.remove('hidden');
                        sizeInfo.textContent = fmtKB(origSize) + ' (kompresi tidak efektif, pakai asli)';
                        return;
                    }

                    const newName = file.name.replace(/\.[^.]+$/, '.jpg');
                    const compressed = new File([blob], newName, { type: 'image/jpeg' });

                    const dt = new DataTransfer();
                    dt.items.add(compressed);
                    input.files = dt.files;

                    preview.src = URL.createObjectURL(blob);
                    wrap.classList.remove('hidden');
                    sizeInfo.textContent = fmtKB(origSize) + ' → ' + fmtKB(blob.size) + ' (dikompresi)';
                }, 'image/jpeg', 0.65);
            };
            img.src = ev.target.result;
        };
        reader.readAsDataURL(file);
    });
})();
</script>
@endsection
