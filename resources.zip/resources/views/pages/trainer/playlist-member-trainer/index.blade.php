@extends('layout.layout')

@php
    $title = 'Riwayat Gym Member';
    $subTitle = 'Riwayat Gym Member';
@endphp

@section('content')

@if(session('error'))
    <x-alert type="danger">{{ session('error') }}</x-alert>
@endif

    <div class="grid grid-cols-12 gap-6">
        <!-- Info Member -->
        <div class="col-span-12">
            <div class="card border-0 overflow-hidden">
                <div class="card-header flex items-center justify-between">
                    <h6 class="card-title mb-0 text-lg">Informasi Member</h6>
                    <div class="flex gap-2">
                        <a href="{{ route('trainer.member.history.export_pdf', $memberTrainer->id) }}"
                            class="btn btn-primary btn-sm">
                            <iconify-icon icon="carbon:document-pdf" class="text-base"></iconify-icon>
                            Export PDF
                        </a>
                        <a href="{{ route('trainer.member.history.export_excel', $memberTrainer->id) }}"
                            class="btn btn-secondary btn-sm">
                            <iconify-icon icon="carbon:document-export" class="text-base"></iconify-icon>
                            Export Excel
                        </a>
                        <a href="{{ route('trainer.dashboard') }}"
                            class="text-neutral-600 hover:text-primary-600 inline-flex items-center">
                            <iconify-icon icon="ion:arrow-back" class="text-2xl"></iconify-icon>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <p class="text-sm text-neutral-600 mb-1">Nama Member</p>
                            <h6 class="font-semibold text-neutral-900">{{ $memberTrainer->anggota->name }}</h6>
                        </div>
                        <div>
                            <p class="text-sm text-neutral-600 mb-1">Paket Training</p>
                            <h6 class="font-semibold text-neutral-900">
                                {{ $memberTrainer->paketPersonalTrainer->nama_paket }}</h6>
                        </div>
                        <div>
                            <p class="text-sm text-neutral-600 mb-1">Progress Sesi</p>
                            <h6 class="font-semibold text-neutral-900">
                                {{ $memberTrainer->sesi }} / {{ $memberTrainer->paketPersonalTrainer->jumlah_sesi }} Sesi
                                <span class="text-sm text-neutral-600">(Sisa: {{ $memberTrainer->sisa_sesi }})</span>
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Riwayat Sesi -->
        <div class="col-span-12">
            <div class="card border-0 overflow-hidden">
                <div class="card-header">
                    <h6 class="card-title mb-0 text-lg">Riwayat Training per Sesi</h6>
                </div>
                <div class="card-body">
                    @if ($history->isEmpty())
                        <div class="text-center py-12">
                            <iconify-icon icon="mdi:clipboard-text-off-outline"
                                class="text-6xl text-neutral-400 mb-4"></iconify-icon>
                            <h5 class="text-xl font-semibold text-neutral-700 mb-2">Belum Ada Riwayat Training</h5>
                            <p class="text-neutral-600">Member ini belum memiliki riwayat training yang tercatat.</p>
                        </div>
                    @else
                        <div class="space-y-6">
                            @foreach ($history as $sesiKe => $playlists)
                                <div class="border border-neutral-200 rounded-lg overflow-hidden mb-5">
                                    <!-- Header Sesi -->
                                    <div class="bg-primary-50 border-b border-primary-200 px-6 py-4">
                                        <div class="flex items-center justify-between flex-wrap gap-2">
                                            <h6 class="font-semibold text-lg text-neutral-900">
                                                <iconify-icon icon="mdi:weight-lifter"
                                                    class="text-primary-600 mr-2"></iconify-icon>
                                                Sesi ke-{{ $sesiKe }}
                                            </h6>
                                            <div class="flex items-center gap-4 text-sm text-neutral-600">
                                                @if (!empty($tanggalPerSesi[$sesiKe]))
                                                    <span class="flex items-center gap-1">
                                                        <iconify-icon icon="mdi:calendar"></iconify-icon>
                                                        {{ $tanggalPerSesi[$sesiKe]->format('d M Y') }}
                                                    </span>
                                                @endif
                                                @if (!empty($durasiPerSesi[$sesiKe]))
                                                    <span class="flex items-center gap-1 font-semibold text-primary-600">
                                                        <iconify-icon icon="mdi:timer-outline"></iconify-icon>
                                                        {{ $durasiPerSesi[$sesiKe] }} menit
                                                    </span>
                                                @endif
                                                <span>{{ $playlists->count() }} Latihan</span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Daftar Playlist -->
                                    <div class="p-6">
                                        @if ($playlists->isEmpty())
                                            <div
                                                class="flex items-center gap-3 p-4 rounded-lg bg-neutral-50 border border-neutral-200">
                                                <iconify-icon icon="mdi:playlist-remove"
                                                    class="text-2xl text-neutral-400"></iconify-icon>
                                                <p class="text-sm text-neutral-500 italic">Sesi ini diselesaikan tanpa data
                                                    playlist tercatat.</p>
                                            </div>
                                        @else
                                            <div class="space-y-4">
                                                @foreach ($playlists as $playlist)
                                                    <div
                                                        class="flex items-start gap-4 p-4 rounded-lg border border-neutral-200">
                                                        <!-- Content -->
                                                        <div class="flex-1">
                                                            <h6 class="font-semibold text-base text-neutral-900 mb-2">
                                                                {{ $playlist->latihan }}
                                                            </h6>

                                                            @if ($playlist->keterangan)
                                                                <div class="bg-white rounded-lg mt-2">
                                                                    <p class="text-xs text-neutral-600 mb-1 font-medium">
                                                                        Keterangan:</p>
                                                                    <p class="text-sm text-neutral-700">
                                                                        {{ $playlist->keterangan }}</p>
                                                                </div>
                                                            @else
                                                                <p class="text-sm text-neutral-500 italic">Tidak ada
                                                                    keterangan</p>
                                                            @endif
                                                        </div>

                                                        <!-- Timestamp -->
                                                        <div class="flex-shrink-0 text-right">
                                                            <p class="text-xs text-neutral-500">
                                                                {{ to_tenant_tz($playlist->created_at)->format('d M Y') }}
                                                            </p>
                                                            <p class="text-xs text-neutral-500">
                                                                {{ to_tenant_tz($playlist->created_at)->format('H:i') }}
                                                            </p>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.remove-button').forEach(button => {
                button.addEventListener('click', function() {
                    const alert = this.closest('.alert');
                    if (alert) alert.remove();
                });
            });
        });
    </script>
@endsection
