<svg {{ $attributes->merge(['class' => '']) }} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="1em" height="1em">
    <path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6"/>
    <path d="M10 20a2 2 0 0 0 4 0"/>
</svg>
