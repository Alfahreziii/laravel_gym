<svg {{ $attributes->merge(['class' => '']) }} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="1em" height="1em">
    <circle cx="12" cy="12" r="9"/>
    <path d="M12 7v5l3 2"/>
</svg>
