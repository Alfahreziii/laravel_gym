<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Anggota;
use App\Models\PembayaranMembership;
use App\Models\PembayaranMemberTrainer;
use App\Models\KehadiranMember;
use App\Models\TransaksiKeuangan;
use App\Models\AkunKeuangan;
use Carbon\Carbon;
use App\Http\Controllers\Concerns\ResolvesMemberExpiry;

class DashboardController extends Controller
{
    use ResolvesMemberExpiry;
    public function index(Request $request)
    {
        $today = tenant_today();

        $memberLakiLaki  = Anggota::where('jenis_kelamin', 'Laki-laki')->count();
        $memberPerempuan = Anggota::where('jenis_kelamin', 'Perempuan')->count();
        $totalMember     = Anggota::count();
        $memberAktif     = Anggota::all()->filter(fn($anggota) => $anggota->status_keanggotaan)->count();
        $memberInGym     = KehadiranMember::whereBetween('created_at', tenant_today_range())
            ->latest()
            ->get()
            ->groupBy('rfid')
            ->map(fn($items) => $items->first())
            ->filter(fn($item) => strtolower($item->status) === 'in')
            ->count();

        // ========================================
        // MEMBER TERBARU (5 pendaftaran terakhir)
        // ========================================
        $todayStr = $today->format('Y-m-d');

        $memberTerbaru = Anggota::with([
            'user',
            'anggotaMemberships' => fn($q) => $q->orderByDesc('tgl_selesai'),
        ])->latest()->take(5)->get()->map(function ($anggota) use ($todayStr) {
            $active = $anggota->anggotaMemberships
                ->filter(fn($m) => $m->tgl_mulai->format('Y-m-d') <= $todayStr && $m->tgl_selesai->format('Y-m-d') >= $todayStr)
                ->first();
            $latest = $active ?? $anggota->anggotaMemberships->first();

            if (!$latest || $latest->tgl_selesai->format('Y-m-d') < $todayStr) {
                $statusLabel = $latest ? 'Expired' : 'Belum daftar';
                $statusType  = $latest ? 'danger' : 'neutral';
            } elseif (\Carbon\Carbon::parse($todayStr)->diffInDays($latest->tgl_selesai->format('Y-m-d')) <= 7) {
                $statusLabel = 'Akan berakhir';
                $statusType  = 'warning';
            } else {
                $statusLabel = 'Aktif';
                $statusType  = 'success';
            }

            return [
                'id'           => $anggota->id,
                'name'         => $anggota->name,
                'email'        => $anggota->user?->email ?? '-',
                'photo_url'    => $anggota->photo_url,
                'nama_paket'   => $latest?->nama_paket ?? '-',
                'tgl_selesai'  => $latest ? $latest->tgl_selesai->format('d M Y') : '-',
                'status_label' => $statusLabel,
                'status_type'  => $statusType,
                'edit_url'     => route('anggota.edit', $anggota->id),
            ];
        });

        // ========================================
        // KEHADIRAN LANGSUNG (hari ini, terbaru 8)
        // ========================================
        $kehadiranLangsung = KehadiranMember::whereBetween('created_at', tenant_today_range())
            ->latest()
            ->take(8)
            ->get();

        // ========================================
        // GRAFIK KEDATANGAN MEMBER (7 hari terakhir, hanya check-in)
        // ========================================
        $tz = tenant_timezone();
        $kedatanganLabels = [];
        $kedatanganData   = [];
        for ($i = 6; $i >= 0; $i--) {
            $day        = Carbon::now($tz)->subDays($i);
            $rangeStart = $day->copy()->startOfDay()->setTimezone(config('app.timezone'));
            $rangeEnd   = $day->copy()->endOfDay()->setTimezone(config('app.timezone'));

            $kedatanganLabels[] = $day->format('d M');
            $kedatanganData[]   = KehadiranMember::where('status', 'in')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd])
                ->count();
        }

        // ========================================
        // DAFTAR TAHUN TERSEDIA
        // ========================================
        $currentYear = date('Y');
        $currentMonth = date('n'); // 1-12

        // Ambil tahun dari pembayaran membership & trainer
        $membershipYears = PembayaranMembership::selectRaw('YEAR(tgl_bayar) as year')
            ->distinct()
            ->pluck('year');

        $trainerYears = PembayaranMemberTrainer::selectRaw('YEAR(tgl_bayar) as year')
            ->distinct()
            ->pluck('year');

        $paymentYears = $membershipYears->merge($trainerYears)->unique()->sort()->values();

        // Ambil tahun dari transaksi produk
        $productYears = TransaksiKeuangan::selectRaw('YEAR(tanggal) as year')
            ->distinct()
            ->pluck('year');

        // Gabungkan semua tahun
        $availableYears = $paymentYears->merge($productYears)->unique()->sort()->values();

        // Jika tidak ada data, tambahkan tahun sekarang
        if ($availableYears->isEmpty()) {
            $availableYears = collect([$currentYear]);
        }

        // ========================================
        // CHART 1: Membership & Personal Trainer
        // ========================================
        $membershipPayments = PembayaranMembership::select('tgl_bayar', 'jumlah_bayar')->get();
        $trainerPayments = PembayaranMemberTrainer::select('tgl_bayar', 'jumlah_bayar')->get();
        $allPayments = $membershipPayments->concat($trainerPayments);

        $totalRevenue = $allPayments->sum('jumlah_bayar');
        $totalRevenueAllYears = $totalRevenue; // Total dari semua tahun

        // Data per tahun untuk Membership & Trainer
        $membershipDataByYear = [];
        foreach ($availableYears as $year) {
            $yearPayments = $allPayments->filter(function ($item) use ($year) {
                return date('Y', strtotime($item->tgl_bayar)) == $year;
            });

            // Revenue per bulan
            $monthlyRevenue = $yearPayments
                ->groupBy(fn($item) => date('M', strtotime($item->tgl_bayar)))
                ->map(fn($row) => $row->sum('jumlah_bayar'));

            $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            $monthlyData = array_map(fn($m) => $monthlyRevenue[$m] ?? 0, $months);

            // Revenue per minggu untuk setiap bulan
            $weeklyDataByMonth = [];
            $monthlyTotals = []; // Total revenue per bulan
            for ($month = 1; $month <= 12; $month++) {
                $weeklyDataByMonth[$month] = $this->getWeeklyDataForMonth($yearPayments, $year, $month, 'tgl_bayar', 'jumlah_bayar');
                $monthlyTotals[$month] = array_sum($weeklyDataByMonth[$month]);
            }

            // Data per hari untuk setiap bulan
            $dailyDataByMonth = [];
            for ($month = 1; $month <= 12; $month++) {
                $dailyDataByMonth[$month] = $this->getDailyDataForMonth($yearPayments, $year, $month, 'tgl_bayar', 'jumlah_bayar');
            }

            $membershipDataByYear[$year] = [
                'monthly' => $monthlyData,
                'weekly' => $weeklyDataByMonth,
                'daily' => $dailyDataByMonth,
                'totalPerYear' => $yearPayments->sum('jumlah_bayar'),
                'totalPerMonth' => $monthlyTotals,
            ];
        }

        // ========================================
        // CHART 2: Penjualan Produk
        // ========================================
        $akunPenjualanProduk = AkunKeuangan::where('kode', 'MOD005')->first();

        $totalProductRevenue = 0;
        $totalProductRevenueAllYears = 0; // Total dari semua tahun
        $productDataByYear = [];

        if ($akunPenjualanProduk) {
            $productSalesData = TransaksiKeuangan::where('akun_id', $akunPenjualanProduk->id)
                ->where('kredit', '>', 0)
                ->select('tanggal', 'kredit')
                ->get();

            $totalProductRevenue = $productSalesData->sum('kredit');
            $totalProductRevenueAllYears = $totalProductRevenue; // Total dari semua tahun

            // Data per tahun untuk Produk
            foreach ($availableYears as $year) {
                $yearProducts = $productSalesData->filter(function ($item) use ($year) {
                    return date('Y', strtotime($item->tanggal)) == $year;
                });

                // Revenue per bulan
                $monthlyProductRevenue = $yearProducts
                    ->groupBy(fn($item) => date('M', strtotime($item->tanggal)))
                    ->map(fn($row) => $row->sum('kredit'));

                $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                $monthlyProductData = array_map(fn($m) => $monthlyProductRevenue[$m] ?? 0, $months);

                // Revenue per minggu untuk setiap bulan
                $weeklyProductDataByMonth = [];
                $monthlyProductTotals = [];
                for ($month = 1; $month <= 12; $month++) {
                    $weeklyProductDataByMonth[$month] = $this->getWeeklyDataForMonth($yearProducts, $year, $month, 'tanggal', 'kredit');
                    $monthlyProductTotals[$month] = array_sum($weeklyProductDataByMonth[$month]);
                }

                // Data per hari untuk setiap bulan
                $dailyProductDataByMonth = [];
                for ($month = 1; $month <= 12; $month++) {
                    $dailyProductDataByMonth[$month] = $this->getDailyDataForMonth($yearProducts, $year, $month, 'tanggal', 'kredit');
                }

                $productDataByYear[$year] = [
                    'monthly' => $monthlyProductData,
                    'weekly' => $weeklyProductDataByMonth,
                    'daily' => $dailyProductDataByMonth,
                    'totalPerYear' => $yearProducts->sum('kredit'),
                    'totalPerMonth' => $monthlyProductTotals,
                ];
            }
        } else {
            // Jika akun tidak ditemukan
            foreach ($availableYears as $year) {
                $weeklyDataByMonth = [];
                $dailyDataByMonth = [];
                $monthlyTotals = [];
                for ($month = 1; $month <= 12; $month++) {
                    $weeklyDataByMonth[$month] = [0, 0, 0, 0, 0, 0];
                    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                    $dailyDataByMonth[$month] = array_fill(0, $daysInMonth, 0);
                    $monthlyTotals[$month] = 0;
                }

                $productDataByYear[$year] = [
                    'monthly' => array_fill(0, 12, 0),
                    'weekly' => $weeklyDataByMonth,
                    'daily' => $dailyDataByMonth,
                    'totalPerYear' => 0,
                    'totalPerMonth' => $monthlyTotals,
                ];
            }
        }

        return view('pages.admin.dashboard.index', compact(
            'totalRevenue',
            'totalProductRevenue',
            'totalRevenueAllYears',
            'totalProductRevenueAllYears',
            'membershipDataByYear',
            'productDataByYear',
            'availableYears',
            'currentYear',
            'currentMonth',
            'totalMember',
            'memberAktif',
            'memberInGym',
            'memberLakiLaki',
            'memberPerempuan',
            'memberTerbaru',
            'kehadiranLangsung',
            'kedatanganLabels',
            'kedatanganData'
        ));
    }

    /**
     * Helper untuk menghitung revenue per minggu dalam satu bulan
     */
    private function getWeeklyDataForMonth($data, $year, $month, $dateField, $amountField)
    {
        // Filter data untuk bulan tertentu
        $monthData = $data->filter(function ($item) use ($year, $month, $dateField) {
            $date = strtotime($item->$dateField);
            return date('Y', $date) == $year && date('n', $date) == $month;
        });

        // Inisialisasi array untuk max 6 minggu (untuk menampung bulan dengan 31 hari)
        $weeklyData = [0, 0, 0, 0, 0, 0];

        // Kelompokkan berdasarkan minggu
        foreach ($monthData as $item) {
            $date = strtotime($item->$dateField);
            $day = (int) date('j', $date); // Tanggal 1-31

            // Tentukan minggu (0-5)
            $weekNumber = (int) floor(($day - 1) / 7);

            // Pastikan week number tidak lebih dari 5
            $weekNumber = min($weekNumber, 5);

            $weeklyData[$weekNumber] += $item->$amountField;
        }

        // Hitung jumlah minggu yang ada di bulan tersebut
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $weeksInMonth = (int) ceil($daysInMonth / 7);

        // Kembalikan hanya minggu yang relevan
        return array_slice($weeklyData, 0, $weeksInMonth);
    }

    /**
     * Helper untuk menghitung revenue per hari dalam satu bulan
     */
    private function getDailyDataForMonth($data, $year, $month, $dateField, $amountField)
    {
        // Filter data untuk bulan tertentu
        $monthData = $data->filter(function ($item) use ($year, $month, $dateField) {
            $date = strtotime($item->$dateField);
            return date('Y', $date) == $year && date('n', $date) == $month;
        });

        // Hitung jumlah hari dalam bulan
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

        // Inisialisasi array untuk setiap hari
        $dailyData = array_fill(0, $daysInMonth, 0);

        // Kelompokkan berdasarkan hari
        foreach ($monthData as $item) {
            $date = strtotime($item->$dateField);
            $day = (int) date('j', $date); // Tanggal 1-31

            // Index dimulai dari 0, jadi day-1
            $dailyData[$day - 1] += $item->$amountField;
        }

        return $dailyData;
    }


    public function kehadiranDatatable(Request $request)
    {
        $search = $request->get('search', '');
        $perPage = (int) $request->get('perPage', 5);
        $page = (int) $request->get('page', 1);

        $query = KehadiranMember::whereBetween('created_at', tenant_today_range())->latest();

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('rfid', 'like', "%{$search}%")
                    ->orWhere('nama', 'like', "%{$search}%")
                    ->orWhere('status', 'like', "%{$search}%");
            });
        }

        $total = (clone $query)->count();
        $data = (clone $query)->skip(($page - 1) * $perPage)->take($perPage)->get();

        $anggotaMap = $this->anggotaMapForRfids($data->pluck('rfid')->all());

        return response()->json([
            'data' => $data->map(function ($item, $index) use ($page, $perPage, $anggotaMap) {
                $expiry = $this->memberExpiryInfo($anggotaMap->get(strtoupper($item->rfid)));

                return [
                    'no'                => (($page - 1) * $perPage) + $index + 1,
                    'rfid'              => $item->rfid,
                    'foto'              => $item->foto ? asset('storage/' . $item->foto) : null,
                    'name'              => $item->nama ?? '-',
                    'status'            => $item->status,
                    'time'              => to_tenant_tz($item->created_at)->format('d M Y H:i'),
                    'profile_photo'     => $expiry['profile_photo'],
                    'expired_at'        => $expiry['expired_at'],
                    'membership_status' => $expiry['membership_status'],
                    'membership_type'   => $expiry['membership_type'],
                ];
            }),
            'total'    => $total,
            'perPage'  => $perPage,
            'page'     => $page,
            'lastPage' => max(1, ceil($total / $perPage)),
        ]);
    }
    public function memberInRoomDatatable(Request $request)
    {
        $search = $request->get('search', '');
        $perPage = (int) $request->get('perPage', 5);
        $page = (int) $request->get('page', 1);

        $all = KehadiranMember::whereBetween('created_at', tenant_today_range())
            ->latest()
            ->get()
            ->groupBy('rfid')
            ->map(fn($items) => $items->first())
            ->filter(fn($item) => strtolower($item->status) === 'in')
            ->values();

        if ($search) {
            $s = strtolower($search);
            $all = $all->filter(function ($item) use ($s) {
                return str_contains(strtolower($item->rfid ?? ''), $s)
                    || str_contains(strtolower($item->nama ?? ''), $s)
                    || str_contains(strtolower($item->status ?? ''), $s);
            })->values();
        }

        $total = $all->count();
        $data = $all->slice(($page - 1) * $perPage, $perPage)->values();

        $anggotaMap = $this->anggotaMapForRfids($data->pluck('rfid')->all());

        return response()->json([
            'data' => $data->map(function ($item, $index) use ($page, $perPage, $anggotaMap) {
                $expiry = $this->memberExpiryInfo($anggotaMap->get(strtoupper($item->rfid)));

                return [
                    'no'                => (($page - 1) * $perPage) + $index + 1,
                    'rfid'              => $item->rfid,
                    'foto'              => $item->foto ? asset('storage/' . $item->foto) : null,
                    'name'              => $item->nama ?? '-',
                    'status'            => $item->status,
                    'time'              => to_tenant_tz($item->created_at)->format('d M Y H:i'),
                    'profile_photo'     => $expiry['profile_photo'],
                    'expired_at'        => $expiry['expired_at'],
                    'membership_status' => $expiry['membership_status'],
                    'membership_type'   => $expiry['membership_type'],
                ];
            }),
            'total'    => $total,
            'perPage'  => $perPage,
            'page'     => $page,
            'lastPage' => max(1, ceil($total / $perPage)),
        ]);
    }
}
